//
//  ViewController.swift
//  StaticTableView
//
//  Created by NDHU_CSIE on 2021/12/13.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

