# FoodPin-CoreData

1. Change the saving strategy to core data

2. Add the edit function to update any restaurant data by swiping action
